import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as firebase from 'firebase';

import {UserService} from './Service/UserService';
import {OrderService} from './Service/OrderService';


import {User} from './Module/user';
import {Order} from './Module/Order';
import { Rate } from './Module/Rate';

admin.initializeApp(functions.config().firebase);

firebase.initializeApp({
    apiKey: 'AIzaSyDnKUBPUThvgs8kskYZ6v2qYaTN_zbSMn8',
    authDomain: "moveout-ab6e5.firebaseapp.com",
    databaseURL:"moveout-ab6e5.firebaseio.com/",
    storageBucket: "moveout-ab6e5.appspot.com",
})

export const createuser = functions.https.onRequest((request,response)=>{
    const user = request.body as User;
    UserService.createuser(user).then(result=>response.send(result)).catch(err=>console.log(err))
})

export const getuserdatabaseid = functions.https.onRequest((request,response)=>{
    const userid = request.query.userid as string;
    UserService.getdatabaseinfo(userid).then(result=>response.send(result)).catch(err=>{console.log(err)})
})

export const getuserbyid = functions.https.onRequest((request,response)=>{
    const key = request.query.key as string;
    UserService.getuserbykey(key).then(result=>response.send(result)).catch(err=>console.log(err))
})

export const getuserbyemail = functions.https.onRequest((request,response)=>{
    const email = request.query.email as string;
    UserService.getuserbyemail(email).then(result=>response.send(result)).catch(err=>console.log(err))
})

export const adduser = functions.https.onRequest((request,response) => {
    const user = request.body as User;
    //response.send(user);

    UserService.adduser(user).then(result=>response.send(result)).catch(err=>console.log(err));
})

export const createorder = functions.https.onRequest((request,response)=>{
    const order = request.body as Order;
    OrderService.createorder(order).then(result=>response.send(result)).catch(err=>console.log(err))
})

export const getorder = functions.https.onRequest((request,response)=>{
    const userid = request.query.userid as string;
    OrderService.getorder(userid).then(result=>response.send(result)).catch(err=>console.log(err));
})

export const setenable = functions.https.onRequest((request,response)=>{
    const orderid = request.query.orderid as string;
    OrderService.setenable(orderid).then(result=>response.send(result)).catch(err=>console.log(err));
})

export const signinuser = functions.https.onRequest((request,response)=>{
    const email = request.query.email as string;
    const password = request.query.password as string;
    UserService.signinuser(email,password).then(result=>response.send(result)).catch(err=>response.send(err));
    
})

export const updateprofile = functions.https.onRequest((request,response)=>{
    const user = request.body as User;
    UserService.updateuser(user).then(result=>response.send(result)).catch(err=>response.send(err))
})

export const getfurniture = functions.https.onRequest((request,response)=>{
    OrderService.getfurniture().then(result=>response.send(result)).catch(err=>response.send(err));
})

export const postrate = functions.https.onRequest((request,response)=>{
    const rate = request.body as Rate;
    OrderService.postrate(rate).then(result=>response.send(result)).catch(err=>response.send(err));
})

export const cancelmove = functions.https.onRequest((request,response)=>{
    const userid = request.query.id as string;
    OrderService.cancelmove(userid).then(result=>response.send(result)).catch(err=>response.send(err));
})