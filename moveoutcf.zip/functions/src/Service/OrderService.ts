import {Order} from '../Module/Order';
import {OrderRepo} from '../Repo/OrderRepo';
import { Rate } from '../Module/Rate';
export class OrderService
{
    public static async createorder(order:Order)
    {
        const repository = new OrderRepo();
        return repository.createorder(order);
    }

    public static async getorder(userid:string)
    {
        const repository = new OrderRepo();
        return repository.getorder(userid);
    }

    public static async setenable(orderid:string)
    {
        const repository = new OrderRepo();
        return repository.setenable(orderid);
    }

    public static async getfurniture()
    {
        const repository = new OrderRepo();
        return repository.getfurniture();
    }

    public static async postrate(rate:Rate)
    {
        const repository = new OrderRepo();
        return repository.postrate(rate);
    }

    public static async cancelmove(userid:string)
    {
        const repository = new OrderRepo();
        return repository.cancelmove(userid);
    }
}