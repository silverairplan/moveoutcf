import {User} from '../Module/user';
import {UserRepo} from '../Repo/User';
// import {DefaultResponse} from '../Repo/DefaultReturn';
export class UserService
{
    public static async createuser(user:User):Promise<Object>
    {
        const repository = new UserRepo();
        return repository.createUser(user);
    }

    public static async getdatabaseinfo(id:string):Promise<any>
    {
        const repository = new UserRepo();
        return repository.getdatabaseinfo(id);
    }

    public static async getuserbykey(key:string):Promise<User>
    {
        const repository = new UserRepo();
        return repository.getuserbykey(key);
    }

    public static async getuserbyemail(email:string):Promise<User>
    {
        const repository = new UserRepo();
        return repository.getuserbyemail(email);
    }

    public static async adduser(user:User):Promise<any>
    {
        const repository = new UserRepo();
        return repository.adduser(user);
    }

    public static async signinuser(email:string,password:string):Promise<Object>
    {
        const repository = new UserRepo();
        return repository.signinuser(email,password);
    }

    public static async updateuser(user:User):Promise<Object>
    {
        const repository = new UserRepo();
        return repository.updateuser(user);
    }
}