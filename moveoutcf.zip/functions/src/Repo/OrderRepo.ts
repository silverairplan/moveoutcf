import {Order,itemCarry} from '../Module/Order';
import {Rate} from '../Module/Rate';
import * as admin from 'firebase-admin';
import {Guid} from 'guid-typescript';

export class OrderRepo
{
    public async createorder(order:Order):Promise<any>
    {
        return new Promise<any>((resolve,reject)=>{
            order.guid = Guid.create().toString();
            admin.firestore().doc('order/' + order.guid).create(order).then(res=>{
                resolve({success:true,orderid:order.guid})
            }).catch(err=>reject(err))
            // admin.database().ref('order').push(order).then(res=>{
            //     resolve({success:true})
            // }).catch(err=>reject(err))
        })
        
    }

    public async getorder(userid:string):Promise<Array<Order>>
    {
        return new Promise<Array<Order>>((resolve,reject)=>{
            admin.firestore().collection('order').where('userid','==',userid).get().then(data=>{
                const result = new Array();
                data.forEach(value=>{
                    result.push(value.data() as Order);
                })

                resolve(result);
            }).catch(err=>reject(err))
        })
    }

    public async setenable(orderid:string):Promise<Object>
    {
        return new Promise<Object>((resolve,reject)=>{
            admin.firestore().doc('order/' + orderid).get().then(result=>{
               const value = result.data() as Order;
               value.state = 'accepted';
               value.termsaccepteddate = new Date();
               //value.active = true;
               admin.firestore().doc('order/' + orderid).set(value).then(item=>{
                   resolve({success:true})
               }).catch(err=>reject(err)) 
            }).catch(err=>reject(err))
        })
    }

    public async getfurniture():Promise<Array<itemCarry>>
    {
        return new Promise<Array<itemCarry>>((resolve,reject)=>{
            admin.firestore().collection('furniture').orderBy('order').get().then(data=>{
                const result = new Array();
                data.forEach(value=>{
                    result.push(value.data() as itemCarry);
                })

                resolve(result);
            }).catch(err=>reject(err))
        })
    }

    public async postrate(rate:Rate):Promise<any>
    {
        return new Promise<any>((resolve,reject)=>{
            rate.guid = Guid.create().toString();
            admin.firestore().doc('rate/' + rate.guid).create(rate).then(res=>{
                resolve({success:true})
            }).catch(err=>resolve({success:false}))       
        })
    }

    public async cancelmove(userid:string):Promise<any>
    {
        return new Promise<any>((resolve,reject)=>{
            admin.firestore().collection('order').where('userid','==',userid).get().then(data=>{
                data.forEach(async(snapshot)=>{
                    const order = snapshot.data() as Order;
                    if(order.state == 'waiting')
                    {
                        await snapshot.ref.delete();
                    }
                })
                resolve({success:true})
            }).catch(err=>resolve({success:false}))
        })
    }
}