import * as admin from 'firebase-admin';
import {User} from '../Module/user';
import * as firebase from 'firebase';
import {Guid} from 'guid-typescript';
export class UserRepo
{
    public async createUser(user:any):Promise<Object>
    {
        return new Promise<Object>((resolve,reject)=>{
            admin.auth().createUser({email:user.email,password:user.password}).then(result=>{
                user.uid = result.uid;
                user.genid = Guid.create().toString();
                
                const realuser = {} as any;

                for(const item in user)
                {
                    if(item !== 'password')
                    {
                        realuser[item] = user[item];
                    }
                }
                
                const user1 = realuser as User;

                
                admin.firestore().doc('user/'+ user1.genid).create(user1).then(res=>{
                    resolve({success:true})
                }).catch(err=>resolve({success:false,error:err}))
            }).catch(err=>resolve({success:false,error:err}))
        })
    }

    public async signinuser(email:string,password:string):Promise<Object>
    {
        return new Promise<Object>((resolve,reject)=>{
            firebase.auth().signInWithEmailAndPassword(email,password).then(user=>{
                admin.auth().getUserByEmail(email).then(result=>{
                    admin.firestore().collection('user').where('uid','==',result.uid)
                    .get().then(snapshot=>{
                        if(!snapshot.empty)
                        {
                            const realuser = snapshot.docs[0].data() as User;
                            realuser.lastaccessdate = new Date();
                            admin.firestore().doc('user/' + realuser.genid).set(realuser).then(res=>{
                                resolve({success:true,user:realuser})
                            }).catch(err=>resolve({success:false}))
                            
                        }
                        else
                        {
                            resolve({success:false,uid:result.uid})
                        }
                    }).catch(err=>resolve({success:false,error:err}))
                })
                .catch(err=>resolve({success:false,error:err}))    
            }).catch(err=>resolve({success:false,error:err}))
           
        })        
    }

   public async getdatabaseinfo(id:string):Promise<any>
   {
      return new Promise<any>((resolve,reject)=>{
       admin.firestore().collection('user').where('uid','==',id).get().then(result=>{
           if(!result.empty)
           {
               const realuser = result.docs[0].data() as User;
               realuser.lastaccessdate = new Date();
               admin.firestore().doc('user/' + realuser.genid).set(realuser).then(res=>{
                    resolve({success:true,user:result.docs[0].data()});
               }).catch(err=>resolve({}))
               
           }
           else
           {
               resolve({})
           }
       }).catch(err=>reject(err))
      })    
   }

   public async getuserbykey(key:string):Promise<User>
   {
       return new Promise<User>((resolve,reject)=>{
           admin.firestore().doc('user/' + key).get().then(data=>{
               resolve(data.data() as User);
           }).catch(err=>reject(err))
       })
   }

   public async getuserbyemail(email:string):Promise<any>
   {
        return new Promise<any>((resolve,reject)=>{
            admin.firestore().collection('user').where("email","==",email).get().then(result=>{
                if(!result.empty)
                {
                    resolve({success:true,user:result.docs[0].data()})
                }
                else
                {
                    resolve({success:false})
                }
            }).catch(err=>reject(err))
        })
    }

    public async adduser(user:User):Promise<any>
    {
        return new Promise<any>((resolve,reject)=>{
            user.genid = Guid.create().toString();
            admin.firestore().doc('user/' + user.genid).create(user).then(res=>{
                resolve({success:true})
            }).catch(err=>reject(err))
        })
    }

    public async updateuser(user:User):Promise<Object>
    {
        return new Promise<Object>((resolve,reject)=>{
            admin.auth().updateUser(user.uid,{email:user.email}).then(result=>{

                admin.firestore().doc('user/' + user.genid).set(user).then(resultuser=>{
                    resolve({success:true,user:user})
                }).catch(err=>resolve({success:false}))
            }).catch(err=>{                
                admin.firestore().doc('user/' + user.genid).set(user).then(resultuser=>{
                    resolve({success:true,user:user})
                }).catch(errres=>resolve({success:false}))
            })
        })
    }
}