/**retorno padrão para a comunicação entre os métodos */
export class DefaultResponse
{
    _code:string;
    _message:string;
    _status:DefaultResponseEnum;
    _object:any;

    protected constructor(code:string, message:string, status:DefaultResponseEnum, object:any)
    {
        this._code = code;
        this._message = message;
        this._status = status;
        this._object = object;
    }

    public static Success(object:any=null):DefaultResponse
    { 
        return new DefaultResponse("0","", 0, object);
    }

    public static Error(code:string, message:string, object:any=null):DefaultResponse
    {
        return new DefaultResponse(code, message, 0, object);
    }

    public static Warning(code:string, message:string, object:any=null)
    {
        return new DefaultResponse(code, message, 2, object);
    }
}


enum DefaultResponseEnum
{
    Error = 0,
    Success = 1,
    Warning = 2
}