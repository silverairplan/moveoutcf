export interface User
{
    name:string;
    profileprofile:string;
    lastaccessdate:Date;
    uid:string;
    email:string;
    cpf:string;
    address:object;
    genid:string;
    socialid:string;
    payment:Payment;
    mobilephone:string;
}

export interface Payment
{
    cardnumber:string;
    transactiondate:Date;
    country:string;
    nsu:string;
}