export interface Rate
{
    orderid:string;
    description:string;
    userid:string;
    mark:string;
    guid:string;
}