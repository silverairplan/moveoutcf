export interface Order
{
    userid:string;
    state:string;
    createdon:Date;
    moveoutdate:Date;
    preferedperiod:string;
    additionalinfo:string;
    termsaccepteddate:Date;
    origin:Location;
    destination:Location;
    itemstocarry:Array<Furniture>;
    simulatedvalue:number;
    carrying:carry;
    payment:Payment;
    guid:string;
}

export interface Furniture
{
    description:string;
    dimension:string;
    isfragile:boolean;
    additionalinfo:string;
    picture:string;
    weightinkg:number;
}

export interface Location
{
    postalcode:string;
    number:number;
    complement:string;
    address:string;
    neightborhood:string;
    city:string;
    state:string;
}

export interface Payment
{
    nsu:number;
    value:number;
    type:string;
    transactiondate:Date;
}

export interface carry
{
    id:string;
    truckid:string;
    additionalinfo:string;
}

export interface itemCarry
{
    name:string;
    large:string;
    small:string;
    data:Array<Furniture>;
}